package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.ReelCountManager
import com.example.data.VideoPlatform
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    private lateinit var context: Context

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext<Context>()
    }

    @Test
    fun `read string from context`() {
        val appName = context.getString(R.string.app_name)
        assertEquals("Reel Counter", appName)
    }

    @Test
    fun `test reel counter increment and reset`() {
        val manager = ReelCountManager.init(context)
        val initialCount = manager.dailyStats.value.totalCount

        manager.incrementCount(VideoPlatform.INSTAGRAM)
        val afterIg = manager.dailyStats.value
        assertEquals(initialCount + 1, afterIg.totalCount)
        assertTrue(afterIg.instagramCount >= 1)

        manager.incrementCount(VideoPlatform.YOUTUBE)
        val afterYt = manager.dailyStats.value
        assertEquals(initialCount + 2, afterYt.totalCount)
        assertTrue(afterYt.youtubeCount >= 1)

        manager.resetToday()
        assertEquals(0, manager.dailyStats.value.totalCount)
    }
}
