package com.example

import android.app.Application
import com.example.data.ReelCountManager

class ReelCounterApp : Application() {
    override fun onCreate() {
        super.onCreate()
        ReelCountManager.init(this)
    }
}
