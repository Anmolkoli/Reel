package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.ReelCountManager
import com.example.service.ReelCounterAccessibilityService
import com.example.ui.screens.MainDashboardScreen
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.MyApplicationTheme
import com.example.util.PermissionUtils

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val countManager = ReelCountManager.getInstance()

        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = DarkBackground
                ) {
                    val stats by countManager.dailyStats.collectAsStateWithLifecycle()
                    val settings by countManager.settings.collectAsStateWithLifecycle()
                    val history by countManager.history.collectAsStateWithLifecycle()
                    val isServiceRunning by ReelCounterAccessibilityService.isServiceActive.collectAsStateWithLifecycle()

                    var isAccessibilityEnabled by remember { mutableStateOf(false) }
                    var isOverlayEnabled by remember { mutableStateOf(false) }
                    var isOverlayPreviewShowing by remember { mutableStateOf(false) }

                    // Refresh permission status when returning to foreground
                    val lifecycleOwner = LocalLifecycleOwner.current
                    DisposableEffect(lifecycleOwner) {
                        val observer = LifecycleEventObserver { _, event ->
                            if (event == Lifecycle.Event.ON_RESUME) {
                                isAccessibilityEnabled = PermissionUtils.isAccessibilityServiceEnabled(this@MainActivity) || isServiceRunning
                                isOverlayEnabled = PermissionUtils.canDrawOverlays(this@MainActivity)
                                isOverlayPreviewShowing = ReelCounterAccessibilityService.isOverlayCurrentlyShowing()
                            }
                        }
                        lifecycleOwner.lifecycle.addObserver(observer)
                        onDispose {
                            lifecycleOwner.lifecycle.removeObserver(observer)
                        }
                    }

                    MainDashboardScreen(
                        stats = stats,
                        settings = settings,
                        history = history,
                        isAccessibilityEnabled = isAccessibilityEnabled || isServiceRunning,
                        isOverlayEnabled = isOverlayEnabled,
                        isOverlayPreviewShowing = isOverlayPreviewShowing,
                        onOpenAccessibility = {
                            PermissionUtils.openAccessibilitySettings(this@MainActivity)
                        },
                        onOpenOverlay = {
                            PermissionUtils.openOverlaySettings(this@MainActivity)
                        },
                        onResetToday = {
                            countManager.resetToday()
                        },
                        onSaveLimit = { newLimit ->
                            countManager.setDailyLimit(newLimit)
                        },
                        onUpdateSettings = { newSettings ->
                            countManager.updateSettings(newSettings)
                        },
                        onManualSwipe = { platform ->
                            ReelCounterAccessibilityService.triggerManualTestSwipe(platform)
                            isOverlayPreviewShowing = ReelCounterAccessibilityService.isOverlayCurrentlyShowing()
                        },
                        onToggleOverlayPreview = { show ->
                            ReelCounterAccessibilityService.toggleOverlayPreview(show)
                            isOverlayPreviewShowing = show
                        }
                    )
                }
            }
        }
    }
}
