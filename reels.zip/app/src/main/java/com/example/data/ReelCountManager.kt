package com.example.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class ReelCountManager private constructor(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val coroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _dailyStats = MutableStateFlow(loadTodayStats())
    val dailyStats: StateFlow<DailyStats> = _dailyStats.asStateFlow()

    private val _settings = MutableStateFlow(loadSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private val _history = MutableStateFlow(loadHistory())
    val history: StateFlow<List<DayHistory>> = _history.asStateFlow()

    init {
        checkMidnightReset()
    }

    private fun getTodayDateString(): String {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return dateFormat.format(Date())
    }

    private fun getDisplayDayString(dateStr: String): String {
        return try {
            val parser = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val date = parser.parse(dateStr) ?: return dateStr
            val formatter = SimpleDateFormat("EEE, MMM d", Locale.getDefault())
            formatter.format(date)
        } catch (e: Exception) {
            dateStr
        }
    }

    @Synchronized
    private fun checkMidnightReset() {
        val today = getTodayDateString()
        val currentStats = _dailyStats.value

        if (currentStats.date != today) {
            // New day detected! Archive previous day if it has any stats
            if (currentStats.totalCount > 0) {
                archiveToHistory(currentStats)
            }
            // Create fresh stats for today
            val newStats = DailyStats(
                date = today,
                totalCount = 0,
                instagramCount = 0,
                youtubeCount = 0,
                tiktokCount = 0,
                facebookCount = 0,
                demoCount = 0,
                dailyLimit = _settings.value.dailyLimit,
                lastUpdatedMillis = System.currentTimeMillis()
            )
            _dailyStats.value = newStats
            saveTodayStats(newStats)
        }
    }

    private fun archiveToHistory(stats: DailyStats) {
        val currentHistory = _history.value.toMutableList()
        // Avoid duplicate entry for same date
        currentHistory.removeAll { it.date == stats.date }
        currentHistory.add(
            0,
            DayHistory(
                date = stats.date,
                displayDay = getDisplayDayString(stats.date),
                totalCount = stats.totalCount,
                instagramCount = stats.instagramCount,
                youtubeCount = stats.youtubeCount,
                tiktokCount = stats.tiktokCount,
                facebookCount = stats.facebookCount,
                demoCount = stats.demoCount
            )
        )
        // Keep up to 14 days
        val trimmed = if (currentHistory.size > 14) currentHistory.take(14) else currentHistory
        _history.value = trimmed
        saveHistory(trimmed)
    }

    @Synchronized
    fun incrementCount(platform: VideoPlatform): DailyStats {
        checkMidnightReset()
        val current = _dailyStats.value
        val config = _settings.value

        // Check if platform is enabled
        val isEnabled = when (platform) {
            VideoPlatform.INSTAGRAM -> config.trackInstagram
            VideoPlatform.YOUTUBE -> config.trackYouTube
            VideoPlatform.TIKTOK -> config.trackTikTok
            VideoPlatform.FACEBOOK -> config.trackFacebook
            VideoPlatform.DEMO -> config.trackDemo
        }

        if (!isEnabled) {
            return current
        }

        val updated = current.copy(
            totalCount = current.totalCount + 1,
            instagramCount = if (platform == VideoPlatform.INSTAGRAM) current.instagramCount + 1 else current.instagramCount,
            youtubeCount = if (platform == VideoPlatform.YOUTUBE) current.youtubeCount + 1 else current.youtubeCount,
            tiktokCount = if (platform == VideoPlatform.TIKTOK) current.tiktokCount + 1 else current.tiktokCount,
            facebookCount = if (platform == VideoPlatform.FACEBOOK) current.facebookCount + 1 else current.facebookCount,
            demoCount = if (platform == VideoPlatform.DEMO) current.demoCount + 1 else current.demoCount,
            lastUpdatedMillis = System.currentTimeMillis()
        )

        _dailyStats.value = updated
        coroutineScope.launch {
            saveTodayStats(updated)
        }
        return updated
    }

    @Synchronized
    fun resetToday() {
        val today = getTodayDateString()
        val reset = DailyStats(
            date = today,
            totalCount = 0,
            instagramCount = 0,
            youtubeCount = 0,
            tiktokCount = 0,
            facebookCount = 0,
            demoCount = 0,
            dailyLimit = _settings.value.dailyLimit,
            lastUpdatedMillis = System.currentTimeMillis()
        )
        _dailyStats.value = reset
        coroutineScope.launch {
            saveTodayStats(reset)
        }
    }

    fun setDailyLimit(limit: Int) {
        val safeLimit = limit.coerceAtLeast(1)
        val updatedSettings = _settings.value.copy(dailyLimit = safeLimit)
        _settings.value = updatedSettings
        _dailyStats.value = _dailyStats.value.copy(dailyLimit = safeLimit)

        coroutineScope.launch {
            saveSettings(updatedSettings)
            saveTodayStats(_dailyStats.value)
        }
    }

    fun updateSettings(newSettings: AppSettings) {
        _settings.value = newSettings
        if (_dailyStats.value.dailyLimit != newSettings.dailyLimit) {
            _dailyStats.value = _dailyStats.value.copy(dailyLimit = newSettings.dailyLimit)
            coroutineScope.launch {
                saveTodayStats(_dailyStats.value)
            }
        }
        coroutineScope.launch {
            saveSettings(newSettings)
        }
    }

    private fun loadTodayStats(): DailyStats {
        val today = getTodayDateString()
        val savedDate = prefs.getString(KEY_DATE, today) ?: today

        val limit = prefs.getInt(KEY_DAILY_LIMIT, 50)
        if (savedDate != today) {
            return DailyStats(date = today, dailyLimit = limit)
        }

        return DailyStats(
            date = today,
            totalCount = prefs.getInt(KEY_TOTAL_COUNT, 0),
            instagramCount = prefs.getInt(KEY_INSTAGRAM_COUNT, 0),
            youtubeCount = prefs.getInt(KEY_YOUTUBE_COUNT, 0),
            tiktokCount = prefs.getInt(KEY_TIKTOK_COUNT, 0),
            facebookCount = prefs.getInt(KEY_FACEBOOK_COUNT, 0),
            demoCount = prefs.getInt(KEY_DEMO_COUNT, 0),
            dailyLimit = limit,
            lastUpdatedMillis = prefs.getLong(KEY_LAST_UPDATED, System.currentTimeMillis())
        )
    }

    private fun saveTodayStats(stats: DailyStats) {
        prefs.edit()
            .putString(KEY_DATE, stats.date)
            .putInt(KEY_TOTAL_COUNT, stats.totalCount)
            .putInt(KEY_INSTAGRAM_COUNT, stats.instagramCount)
            .putInt(KEY_YOUTUBE_COUNT, stats.youtubeCount)
            .putInt(KEY_TIKTOK_COUNT, stats.tiktokCount)
            .putInt(KEY_FACEBOOK_COUNT, stats.facebookCount)
            .putInt(KEY_DEMO_COUNT, stats.demoCount)
            .putInt(KEY_DAILY_LIMIT, stats.dailyLimit)
            .putLong(KEY_LAST_UPDATED, stats.lastUpdatedMillis)
            .apply()
    }

    private fun loadSettings(): AppSettings {
        return AppSettings(
            dailyLimit = prefs.getInt(KEY_DAILY_LIMIT, 50),
            vibrateOnScroll = prefs.getBoolean(KEY_VIBRATE, true),
            autoHideOverlay = prefs.getBoolean(KEY_AUTO_HIDE, true),
            trackInstagram = prefs.getBoolean(KEY_TRACK_IG, true),
            trackYouTube = prefs.getBoolean(KEY_TRACK_YT, true),
            trackTikTok = prefs.getBoolean(KEY_TRACK_TT, true),
            trackFacebook = prefs.getBoolean(KEY_TRACK_FB, true),
            trackDemo = prefs.getBoolean(KEY_TRACK_DEMO, true),
            scrollDebounceMs = prefs.getLong(KEY_DEBOUNCE_MS, 700L)
        )
    }

    private fun saveSettings(settings: AppSettings) {
        prefs.edit()
            .putInt(KEY_DAILY_LIMIT, settings.dailyLimit)
            .putBoolean(KEY_VIBRATE, settings.vibrateOnScroll)
            .putBoolean(KEY_AUTO_HIDE, settings.autoHideOverlay)
            .putBoolean(KEY_TRACK_IG, settings.trackInstagram)
            .putBoolean(KEY_TRACK_YT, settings.trackYouTube)
            .putBoolean(KEY_TRACK_TT, settings.trackTikTok)
            .putBoolean(KEY_TRACK_FB, settings.trackFacebook)
            .putBoolean(KEY_TRACK_DEMO, settings.trackDemo)
            .putLong(KEY_DEBOUNCE_MS, settings.scrollDebounceMs)
            .apply()
    }

    private fun loadHistory(): List<DayHistory> {
        val rawJson = prefs.getString(KEY_HISTORY, null)
        if (rawJson.isNullOrBlank()) {
            return generateInitialSampleHistory()
        }
        return try {
            val list = mutableListOf<DayHistory>()
            val array = JSONArray(rawJson)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    DayHistory(
                        date = obj.optString("date", ""),
                        displayDay = obj.optString("displayDay", ""),
                        totalCount = obj.optInt("totalCount", 0),
                        instagramCount = obj.optInt("instagramCount", 0),
                        youtubeCount = obj.optInt("youtubeCount", 0),
                        tiktokCount = obj.optInt("tiktokCount", 0),
                        facebookCount = obj.optInt("facebookCount", 0),
                        demoCount = obj.optInt("demoCount", 0)
                    )
                )
            }
            list
        } catch (e: Exception) {
            generateInitialSampleHistory()
        }
    }

    private fun saveHistory(history: List<DayHistory>) {
        try {
            val array = JSONArray()
            history.forEach { item ->
                val obj = JSONObject().apply {
                    put("date", item.date)
                    put("displayDay", item.displayDay)
                    put("totalCount", item.totalCount)
                    put("instagramCount", item.instagramCount)
                    put("youtubeCount", item.youtubeCount)
                    put("tiktokCount", item.tiktokCount)
                    put("facebookCount", item.facebookCount)
                    put("demoCount", item.demoCount)
                }
                array.put(obj)
            }
            prefs.edit().putString(KEY_HISTORY, array.toString()).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun generateInitialSampleHistory(): List<DayHistory> {
        val list = mutableListOf<DayHistory>()
        val cal = Calendar.getInstance()
        val parser = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val display = SimpleDateFormat("EEE, MMM d", Locale.getDefault())

        // Generate past 5 days sample stats to populate trend charts initially
        val sampleCounts = listOf(42, 68, 35, 84, 51)
        for (i in 1..5) {
            cal.add(Calendar.DAY_OF_YEAR, -1)
            val d = cal.time
            val dateStr = parser.format(d)
            val count = sampleCounts[i - 1]
            list.add(
                DayHistory(
                    date = dateStr,
                    displayDay = display.format(d),
                    totalCount = count,
                    instagramCount = (count * 0.45).toInt(),
                    youtubeCount = (count * 0.35).toInt(),
                    tiktokCount = (count * 0.15).toInt(),
                    facebookCount = (count * 0.05).toInt(),
                    demoCount = 0
                )
            )
        }
        return list
    }

    companion object {
        private const val PREFS_NAME = "reel_counter_prefs"

        private const val KEY_DATE = "date"
        private const val KEY_TOTAL_COUNT = "total_count"
        private const val KEY_INSTAGRAM_COUNT = "instagram_count"
        private const val KEY_YOUTUBE_COUNT = "youtube_count"
        private const val KEY_TIKTOK_COUNT = "tiktok_count"
        private const val KEY_FACEBOOK_COUNT = "facebook_count"
        private const val KEY_DEMO_COUNT = "demo_count"
        private const val KEY_DAILY_LIMIT = "daily_limit"
        private const val KEY_LAST_UPDATED = "last_updated"

        private const val KEY_VIBRATE = "vibrate"
        private const val KEY_AUTO_HIDE = "auto_hide"
        private const val KEY_TRACK_IG = "track_ig"
        private const val KEY_TRACK_YT = "track_yt"
        private const val KEY_TRACK_TT = "track_tt"
        private const val KEY_TRACK_FB = "track_fb"
        private const val KEY_TRACK_DEMO = "track_demo"
        private const val KEY_DEBOUNCE_MS = "debounce_ms"
        private const val KEY_HISTORY = "history_json"

        @Volatile
        private var INSTANCE: ReelCountManager? = null

        fun init(context: Context): ReelCountManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: ReelCountManager(context).also { INSTANCE = it }
            }
        }

        fun getInstance(): ReelCountManager {
            return INSTANCE ?: throw IllegalStateException("ReelCountManager must be initialized in Application class")
        }
    }
}
