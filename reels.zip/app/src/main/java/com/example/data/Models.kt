package com.example.data

import androidx.compose.ui.graphics.Color

enum class VideoPlatform(
    val displayName: String,
    val packageNames: List<String>,
    val badgeColorHex: Long,
    val shortCode: String
) {
    INSTAGRAM(
        displayName = "Instagram Reels",
        packageNames = listOf("com.instagram.android"),
        badgeColorHex = 0xFFE1306C,
        shortCode = "IG"
    ),
    YOUTUBE(
        displayName = "YouTube Shorts",
        packageNames = listOf("com.google.android.youtube"),
        badgeColorHex = 0xFFFF0000,
        shortCode = "YT"
    ),
    TIKTOK(
        displayName = "TikTok",
        packageNames = listOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill"),
        badgeColorHex = 0xFF00F2FE,
        shortCode = "TT"
    ),
    FACEBOOK(
        displayName = "Facebook Reels",
        packageNames = listOf("com.facebook.katana"),
        badgeColorHex = 0xFF1877F2,
        shortCode = "FB"
    ),
    DEMO(
        displayName = "In-App Simulator",
        packageNames = listOf("com.example", "com.aistudio.reelcounter.pxyt"),
        badgeColorHex = 0xFF9C27B0,
        shortCode = "SIM"
    );

    val composeColor: Color
        get() = Color(badgeColorHex)

    companion object {
        fun fromPackage(packageName: String?): VideoPlatform? {
            if (packageName == null) return null
            return entries.firstOrNull { platform ->
                platform.packageNames.any { pkg -> packageName.startsWith(pkg, ignoreCase = true) }
            }
        }
    }
}

data class DailyStats(
    val date: String,
    val totalCount: Int = 0,
    val instagramCount: Int = 0,
    val youtubeCount: Int = 0,
    val tiktokCount: Int = 0,
    val facebookCount: Int = 0,
    val demoCount: Int = 0,
    val dailyLimit: Int = 50,
    val lastUpdatedMillis: Long = System.currentTimeMillis()
) {
    val isOverLimit: Boolean
        get() = totalCount >= dailyLimit

    val limitProgress: Float
        get() = if (dailyLimit > 0) (totalCount.toFloat() / dailyLimit).coerceIn(0f, 1f) else 0f

    // Rough estimate of time spent doomscrolling (avg 35 seconds per reel)
    val estimatedMinutesSpent: Int
        get() = (totalCount * 35) / 60
}

data class AppSettings(
    val dailyLimit: Int = 50,
    val vibrateOnScroll: Boolean = true,
    val autoHideOverlay: Boolean = true,
    val trackInstagram: Boolean = true,
    val trackYouTube: Boolean = true,
    val trackTikTok: Boolean = true,
    val trackFacebook: Boolean = true,
    val trackDemo: Boolean = true,
    val scrollDebounceMs: Long = 700L
)

data class DayHistory(
    val date: String,
    val displayDay: String,
    val totalCount: Int,
    val instagramCount: Int,
    val youtubeCount: Int,
    val tiktokCount: Int,
    val facebookCount: Int,
    val demoCount: Int
)
