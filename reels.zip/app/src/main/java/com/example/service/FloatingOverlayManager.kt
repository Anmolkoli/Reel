package com.example.service

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.example.MainActivity
import com.example.data.DailyStats
import com.example.data.ReelCountManager
import com.example.data.VideoPlatform
import com.example.util.PermissionUtils
import kotlin.math.abs

class FloatingOverlayManager(private val context: Context) {

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val mainHandler = Handler(Looper.getMainLooper())

    private var overlayRootView: FrameLayout? = null
    private var params: WindowManager.LayoutParams? = null

    // UI elements inside pill
    private var pillContainer: LinearLayout? = null
    private var badgeDot: View? = null
    private var countText: TextView? = null
    private var platformText: TextView? = null
    private var expandedContainer: LinearLayout? = null
    private var breakdownText: TextView? = null

    private var isExpanded = false
    private var isShowing = false
    private var currentPlatform: VideoPlatform? = null

    fun show() {
        mainHandler.post {
            if (isShowing) return@post
            if (!PermissionUtils.canDrawOverlays(context)) return@post

            try {
                if (overlayRootView == null) {
                    createOverlayView()
                }
                overlayRootView?.let { view ->
                    if (view.parent == null) {
                        windowManager.addView(view, params)
                        isShowing = true
                        val manager = ReelCountManager.getInstance()
                        updateContent(manager.dailyStats.value, currentPlatform)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun hide() {
        mainHandler.post {
            if (!isShowing) return@post
            try {
                overlayRootView?.let { view ->
                    if (view.parent != null) {
                        windowManager.removeView(view)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                isShowing = false
            }
        }
    }

    fun updateCount(stats: DailyStats, platform: VideoPlatform?) {
        currentPlatform = platform
        mainHandler.post {
            if (isShowing) {
                updateContent(stats, platform)
            }
        }
    }

    fun isOverlayActive(): Boolean = isShowing

    private fun createOverlayView() {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dpToPx(24)
            y = dpToPx(120)
        }

        val root = FrameLayout(context).apply {
            clipChildren = false
            clipToPadding = false
        }

        val cardLayout = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }

        // 1. Draggable Pill Container
        val pill = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dpToPx(12), dpToPx(8), dpToPx(14), dpToPx(8))
            background = createPillBackground(isWarning = false)
            elevation = dpToPx(8).toFloat()
        }

        // Glowing flame or status dot
        val dot = View(context).apply {
            layoutParams = LinearLayout.LayoutParams(dpToPx(10), dpToPx(10)).apply {
                marginEnd = dpToPx(8)
            }
            background = createDotDrawable(Color.parseColor("#FF5722"))
        }

        val pText = TextView(context).apply {
            text = "REELS"
            textSize = 10f
            setTextColor(Color.parseColor("#B0A8D0"))
            paint.isFakeBoldText = true
            setPadding(0, 0, dpToPx(6), 0)
        }

        val cText = TextView(context).apply {
            text = "0"
            textSize = 15f
            setTextColor(Color.WHITE)
            paint.isFakeBoldText = true
        }

        val dragIcon = TextView(context).apply {
            text = " ⠿"
            textSize = 12f
            setTextColor(Color.parseColor("#787090"))
            setPadding(dpToPx(4), 0, 0, 0)
        }

        pill.addView(dot)
        pill.addView(pText)
        pill.addView(cText)
        pill.addView(dragIcon)

        // 2. Expandable Stats Panel (Toggled on tap)
        val expandedPanel = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(dpToPx(14), dpToPx(10), dpToPx(14), dpToPx(10))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dpToPx(6)
            }
            background = createExpandedBackground()
            elevation = dpToPx(10).toFloat()
        }

        val headerText = TextView(context).apply {
            text = "📊 Today's Reels Breakdown"
            textSize = 12f
            setTextColor(Color.parseColor("#FF8E3C"))
            paint.isFakeBoldText = true
        }

        val bText = TextView(context).apply {
            text = "Instagram: 0\nYouTube: 0\nTikTok: 0"
            textSize = 11f
            setTextColor(Color.parseColor("#E0E0E0"))
            setLineSpacing(dpToPx(2).toFloat(), 1f)
            setPadding(0, dpToPx(4), 0, dpToPx(8))
        }

        // Action Buttons Row inside expanded card
        val buttonRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        val openAppBtn = TextView(context).apply {
            text = "Open App"
            textSize = 11f
            setTextColor(Color.WHITE)
            paint.isFakeBoldText = true
            setPadding(dpToPx(10), dpToPx(5), dpToPx(10), dpToPx(5))
            background = createButtonBackground(Color.parseColor("#7C4DFF"))
            setOnClickListener {
                val intent = Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                }
                context.startActivity(intent)
                toggleExpanded(false)
            }
        }

        val hideBtn = TextView(context).apply {
            text = "Hide"
            textSize = 11f
            setTextColor(Color.parseColor("#FF7070"))
            paint.isFakeBoldText = true
            setPadding(dpToPx(10), dpToPx(5), dpToPx(10), dpToPx(5))
            background = createButtonBackground(Color.parseColor("#382028"))
            val marginParam = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                marginStart = dpToPx(8)
            }
            layoutParams = marginParam
            setOnClickListener {
                hide()
            }
        }

        buttonRow.addView(openAppBtn)
        buttonRow.addView(hideBtn)

        expandedPanel.addView(headerText)
        expandedPanel.addView(bText)
        expandedPanel.addView(buttonRow)

        cardLayout.addView(pill)
        cardLayout.addView(expandedPanel)
        root.addView(cardLayout)

        // Setup Drag & Click Handlers
        setupTouchListener(pill)

        // Store references
        overlayRootView = root
        pillContainer = pill
        badgeDot = dot
        countText = cText
        platformText = pText
        expandedContainer = expandedPanel
        breakdownText = bText
    }

    private fun setupTouchListener(view: View) {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isDragging = false

        view.setOnTouchListener { _, event ->
            val p = params ?: return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = p.x
                    initialY = p.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()

                    if (abs(dx) > dpToPx(6) || abs(dy) > dpToPx(6)) {
                        isDragging = true
                    }

                    if (isDragging) {
                        p.x = initialX + dx
                        p.y = initialY + dy
                        try {
                            windowManager.updateViewLayout(overlayRootView, p)
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                    true
                }

                MotionEvent.ACTION_UP -> {
                    if (!isDragging) {
                        // User clicked! Toggle expanded view
                        toggleExpanded(!isExpanded)
                    }
                    true
                }

                else -> false
            }
        }
    }

    private fun toggleExpanded(expand: Boolean) {
        isExpanded = expand
        expandedContainer?.visibility = if (expand) View.VISIBLE else View.GONE
    }

    private fun updateContent(stats: DailyStats, platform: VideoPlatform?) {
        val p = platform ?: VideoPlatform.INSTAGRAM
        val isWarning = stats.isOverLimit

        countText?.text = "${stats.totalCount}"
        platformText?.text = p.shortCode

        // Update dot color based on platform
        val dotColor = if (isWarning) Color.parseColor("#FF1744") else p.badgeColorHex.toInt()
        badgeDot?.background = createDotDrawable(dotColor)

        // Update pill border/tint if over limit
        pillContainer?.background = createPillBackground(isWarning)

        // Update expanded details
        breakdownText?.text = buildString {
            append("Total Watched: ${stats.totalCount} / ${stats.dailyLimit} limit\n")
            append("• Instagram: ${stats.instagramCount}\n")
            append("• YouTube: ${stats.youtubeCount}\n")
            append("• TikTok: ${stats.tiktokCount}\n")
            append("• Facebook: ${stats.facebookCount}\n")
            if (stats.demoCount > 0) {
                append("• Simulator: ${stats.demoCount}\n")
            }
            append("Est. Screen Time: ~${stats.estimatedMinutesSpent} mins")
        }
    }

    private fun createPillBackground(isWarning: Boolean): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpToPx(24).toFloat()
            setColor(Color.parseColor("#EE161324"))
            val strokeColor = if (isWarning) Color.parseColor("#FF1744") else Color.parseColor("#5A4B82")
            setStroke(dpToPx(if (isWarning) 2 else 1), strokeColor)
        }
    }

    private fun createExpandedBackground(): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpToPx(16).toFloat()
            setColor(Color.parseColor("#F5161324"))
            setStroke(dpToPx(1), Color.parseColor("#7C4DFF"))
        }
    }

    private fun createButtonBackground(color: Int): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpToPx(8).toFloat()
            setColor(color)
        }
    }

    private fun createDotDrawable(color: Int): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
        }
    }

    private fun dpToPx(dp: Int): Int {
        val density = context.resources.displayMetrics.density
        return (dp * density).toInt()
    }

    fun onDestroy() {
        hide()
        overlayRootView = null
    }
}
