package com.example.service

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.os.Build
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.example.data.DailyStats
import com.example.data.ReelCountManager
import com.example.data.VideoPlatform
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.math.abs

class ReelCounterAccessibilityService : AccessibilityService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var statsJob: Job? = null

    private var overlayManager: FloatingOverlayManager? = null
    private var lastScrollTimestamp = 0L
    private var currentActivePlatform: VideoPlatform? = null
    private var lastActivePackage: String? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.d(TAG, "ReelCounterAccessibilityService connected")
        instance = this
        _isServiceActive.value = true

        overlayManager = FloatingOverlayManager(applicationContext)

        val manager = ReelCountManager.getInstance()
        statsJob?.cancel()
        statsJob = serviceScope.launch {
            manager.dailyStats.collect { stats ->
                overlayManager?.updateCount(stats, currentActivePlatform)
            }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val packageName = event.packageName?.toString() ?: return

        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                handleWindowStateChanged(packageName, event)
            }

            AccessibilityEvent.TYPE_VIEW_SCROLLED -> {
                handleViewScrolled(packageName, event)
            }
        }
    }

    private fun handleWindowStateChanged(packageName: String, event: AccessibilityEvent) {
        lastActivePackage = packageName
        val platform = VideoPlatform.fromPackage(packageName)
        currentActivePlatform = platform

        val settings = ReelCountManager.getInstance().settings.value

        if (platform != null) {
            // User entered a target video platform (or demo)
            val isEnabled = when (platform) {
                VideoPlatform.INSTAGRAM -> settings.trackInstagram
                VideoPlatform.YOUTUBE -> settings.trackYouTube
                VideoPlatform.TIKTOK -> settings.trackTikTok
                VideoPlatform.FACEBOOK -> settings.trackFacebook
                VideoPlatform.DEMO -> settings.trackDemo
            }

            if (isEnabled) {
                overlayManager?.show()
                val stats = ReelCountManager.getInstance().dailyStats.value
                overlayManager?.updateCount(stats, platform)
            }
        } else {
            // User moved away from target apps
            if (settings.autoHideOverlay) {
                overlayManager?.hide()
            }
        }
    }

    private fun handleViewScrolled(packageName: String, event: AccessibilityEvent) {
        val platform = VideoPlatform.fromPackage(packageName) ?: return
        val manager = ReelCountManager.getInstance()
        val settings = manager.settings.value

        // Check if platform is enabled in settings
        val isEnabled = when (platform) {
            VideoPlatform.INSTAGRAM -> settings.trackInstagram
            VideoPlatform.YOUTUBE -> settings.trackYouTube
            VideoPlatform.TIKTOK -> settings.trackTikTok
            VideoPlatform.FACEBOOK -> settings.trackFacebook
            VideoPlatform.DEMO -> settings.trackDemo
        }
        if (!isEnabled) return

        val now = SystemClock.elapsedRealtime()
        val debounce = settings.scrollDebounceMs

        // Debounce: prevent multiple micro-scroll events during a single swipe gesture
        if (now - lastScrollTimestamp < debounce) {
            return
        }

        // Differentiate normal feed scroll vs vertical reel/shorts swipe
        val isVerticalSwipe = isLikelyReelOrShortsSwipe(platform, event)
        if (!isVerticalSwipe) {
            return
        }

        lastScrollTimestamp = now
        currentActivePlatform = platform

        // Make sure overlay is visible
        overlayManager?.show()

        // Increment count
        val updated = manager.incrementCount(platform)
        overlayManager?.updateCount(updated, platform)

        // Haptic feedback
        if (settings.vibrateOnScroll) {
            vibrateTick()
        }

        Log.d(TAG, "Reel counted on ${platform.displayName}! Today total: ${updated.totalCount}")
    }

    /**
     * Inspects event properties and view hierarchy to differentiate between
     * general horizontal carousel / tiny feed movements and full-screen vertical video swiping.
     */
    private fun isLikelyReelOrShortsSwipe(platform: VideoPlatform, event: AccessibilityEvent): Boolean {
        // 1. Check scroll delta if available (Android 10+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val deltaY = event.scrollDeltaY
            val deltaX = event.scrollDeltaX

            // If it's a dominant horizontal scroll (e.g., stories carousel), ignore it
            if (abs(deltaX) > abs(deltaY) && abs(deltaX) > 20) {
                return false
            }

            // If there's a strong vertical movement, it's a candidate
            if (abs(deltaY) >= 15) {
                return true
            }
        }

        // 2. Check source class name (ViewPager, ViewPager2, RecyclerView full screen pagers)
        val className = event.className?.toString() ?: ""
        if (className.contains("ViewPager", ignoreCase = true) ||
            className.contains("Pager", ignoreCase = true)
        ) {
            return true
        }

        // 3. Inspect view hierarchy identifiers for Reels / Shorts
        try {
            val rootNode = rootInActiveWindow
            if (rootNode != null) {
                val isShortsOrReelsNode = inspectNodeForReels(rootNode, platform)
                rootNode.recycle()
                if (isShortsOrReelsNode) {
                    return true
                }
            }
        } catch (e: Exception) {
            // Ignore node traversal errors
        }

        // 4. Check index change (fromIndex != toIndex) or item scroll on RecyclerView
        if (event.fromIndex >= 0 && event.toIndex >= 0 && event.fromIndex != event.toIndex) {
            return true
        }

        // 5. Fallback for TikTok and Demo where vertical pager swiping is the primary mode
        if (platform == VideoPlatform.TIKTOK || platform == VideoPlatform.DEMO) {
            return true
        }

        // Generic vertical scroll check
        return event.isScrollable
    }

    private fun inspectNodeForReels(node: AccessibilityNodeInfo, platform: VideoPlatform): Boolean {
        val keywords = when (platform) {
            VideoPlatform.INSTAGRAM -> listOf("reel", "clips", "video_container", "reels_viewer", "clips_viewer")
            VideoPlatform.YOUTUBE -> listOf("shorts", "reel", "player_container", "watch_while")
            VideoPlatform.FACEBOOK -> listOf("reel", "watch", "video")
            VideoPlatform.TIKTOK -> listOf("video", "pager", "feed")
            VideoPlatform.DEMO -> listOf("demo", "reel")
        }

        val resId = node.viewIdResourceName?.lowercase() ?: ""
        val text = node.text?.toString()?.lowercase() ?: ""
        val desc = node.contentDescription?.toString()?.lowercase() ?: ""

        for (kw in keywords) {
            if (resId.contains(kw) || text.contains(kw) || desc.contains(kw)) {
                return true
            }
        }

        // Search children up to depth 3
        val childCount = node.childCount
        for (i in 0 until childCount.coerceAtMost(6)) {
            val child = node.getChild(i) ?: continue
            val found = inspectNodeForReels(child, platform)
            child.recycle()
            if (found) return true
        }

        return false
    }

    private fun vibrateTick() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(
                    VibrationEffect.createOneShot(35, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(VibrationEffect.createOneShot(35, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(35)
                }
            }
        } catch (e: Exception) {
            // Ignore vibration failures on devices without vibrator
        }
    }

    override fun onInterrupt() {
        Log.d(TAG, "ReelCounterAccessibilityService interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "ReelCounterAccessibilityService destroyed")
        _isServiceActive.value = false
        statsJob?.cancel()
        overlayManager?.onDestroy()
        overlayManager = null
        instance = null
    }

    companion object {
        private const val TAG = "ReelCounterService"

        private val _isServiceActive = MutableStateFlow(false)
        val isServiceActive: StateFlow<Boolean> = _isServiceActive.asStateFlow()

        @Volatile
        private var instance: ReelCounterAccessibilityService? = null

        fun triggerManualTestSwipe(platform: VideoPlatform = VideoPlatform.DEMO): DailyStats {
            val srv = instance
            val manager = ReelCountManager.getInstance()
            val updated = manager.incrementCount(platform)

            srv?.overlayManager?.show()
            srv?.overlayManager?.updateCount(updated, platform)
            srv?.vibrateTick()

            return updated
        }

        fun toggleOverlayPreview(show: Boolean) {
            val srv = instance ?: return
            if (show) {
                srv.overlayManager?.show()
                val stats = ReelCountManager.getInstance().dailyStats.value
                srv.overlayManager?.updateCount(stats, VideoPlatform.DEMO)
            } else {
                srv.overlayManager?.hide()
            }
        }

        fun isOverlayCurrentlyShowing(): Boolean {
            return instance?.overlayManager?.isOverlayActive() ?: false
        }
    }
}
