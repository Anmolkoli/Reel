package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AppSettings
import com.example.data.DailyStats
import com.example.data.VideoPlatform
import com.example.ui.theme.DarkCardSurface
import com.example.ui.theme.DarkElevatedSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun PlatformGridSection(
    stats: DailyStats,
    settings: AppSettings,
    onTogglePlatform: (VideoPlatform, Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Target Platforms",
                color = TextPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Tap switch to monitor",
                color = TextMuted,
                fontSize = 12.sp
            )
        }

        // Instagram Card
        PlatformItemRow(
            platform = VideoPlatform.INSTAGRAM,
            count = stats.instagramCount,
            total = stats.totalCount,
            isEnabled = settings.trackInstagram,
            onToggle = { onTogglePlatform(VideoPlatform.INSTAGRAM, it) }
        )

        // YouTube Shorts Card
        PlatformItemRow(
            platform = VideoPlatform.YOUTUBE,
            count = stats.youtubeCount,
            total = stats.totalCount,
            isEnabled = settings.trackYouTube,
            onToggle = { onTogglePlatform(VideoPlatform.YOUTUBE, it) }
        )

        // TikTok Card
        PlatformItemRow(
            platform = VideoPlatform.TIKTOK,
            count = stats.tiktokCount,
            total = stats.totalCount,
            isEnabled = settings.trackTikTok,
            onToggle = { onTogglePlatform(VideoPlatform.TIKTOK, it) }
        )

        // Facebook Reels Card
        PlatformItemRow(
            platform = VideoPlatform.FACEBOOK,
            count = stats.facebookCount,
            total = stats.totalCount,
            isEnabled = settings.trackFacebook,
            onToggle = { onTogglePlatform(VideoPlatform.FACEBOOK, it) }
        )
    }
}

@Composable
private fun PlatformItemRow(
    platform: VideoPlatform,
    count: Int,
    total: Int,
    isEnabled: Boolean,
    onToggle: (Boolean) -> Unit
) {
    val percentage = if (total > 0) ((count.toFloat() / total) * 100).toInt() else 0

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("platform_card_${platform.name.lowercase()}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isEnabled) platform.composeColor.copy(alpha = 0.35f) else Color.Transparent
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Platform badge
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(platform.composeColor.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = platform.shortCode,
                    color = platform.composeColor,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = platform.displayName,
                    color = TextPrimary,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp
                )
                Text(
                    text = if (isEnabled) "$count watched ($percentage%)" else "Monitoring disabled",
                    color = if (isEnabled) TextSecondary else TextMuted,
                    fontSize = 12.sp
                )
            }

            // Big Count badge
            Text(
                text = "$count",
                color = platform.composeColor,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                modifier = Modifier.padding(end = 12.dp)
            )

            // Switch
            Switch(
                checked = isEnabled,
                onCheckedChange = onToggle,
                modifier = Modifier.testTag("switch_${platform.name.lowercase()}"),
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.White,
                    checkedTrackColor = platform.composeColor,
                    uncheckedThumbColor = TextMuted,
                    uncheckedTrackColor = DarkElevatedSurface
                )
            )
        }
    }
}
