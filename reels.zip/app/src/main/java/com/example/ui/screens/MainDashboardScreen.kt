package com.example.ui.screens

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AppSettings
import com.example.data.DailyStats
import com.example.data.DayHistory
import com.example.data.VideoPlatform
import com.example.ui.components.HeroCounterCard
import com.example.ui.components.HistorySection
import com.example.ui.components.PermissionCardsSection
import com.example.ui.components.PlatformGridSection
import com.example.ui.components.ReelsSimulatorSection
import com.example.ui.components.ResetConfirmDialog
import com.example.ui.components.SetLimitDialog
import com.example.ui.components.SetupGuideDialog
import com.example.ui.theme.CoralPrimary
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkCardSurface
import com.example.ui.theme.DarkElevatedSurface
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainDashboardScreen(
    stats: DailyStats,
    settings: AppSettings,
    history: List<DayHistory>,
    isAccessibilityEnabled: Boolean,
    isOverlayEnabled: Boolean,
    isOverlayPreviewShowing: Boolean,
    onOpenAccessibility: () -> Unit,
    onOpenOverlay: () -> Unit,
    onResetToday: () -> Unit,
    onSaveLimit: (Int) -> Unit,
    onUpdateSettings: (AppSettings) -> Unit,
    onManualSwipe: (VideoPlatform) -> Unit,
    onToggleOverlayPreview: (Boolean) -> Unit
) {
    var showSetLimitDialog by remember { mutableStateOf(false) }
    var showResetConfirmDialog by remember { mutableStateOf(false) }
    var showGuideDialog by remember { mutableStateOf(false) }

    val isServiceFullyReady = isAccessibilityEnabled && isOverlayEnabled

    // Pulsing animation for the status dot
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Pulsing status dot
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(
                                    if (isServiceFullyReady) Color(0xFF00E676).copy(alpha = pulseAlpha)
                                    else WarningAmber.copy(alpha = pulseAlpha)
                                )
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Reel Counter",
                                color = TextPrimary,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 18.sp
                            )
                            Text(
                                text = if (isServiceFullyReady) "Active • Watching Gestures" else "Setup Required",
                                color = if (isServiceFullyReady) Color(0xFF00E676) else WarningAmber,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showGuideDialog = true },
                        modifier = Modifier.testTag("btn_help_guide")
                    ) {
                        Icon(
                            imageVector = Icons.Default.HelpOutline,
                            contentDescription = "Setup Guide",
                            tint = TextSecondary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkBackground
                )
            )
        },
        containerColor = DarkBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Permission Cards (Accessibility + Overlay)
            PermissionCardsSection(
                isAccessibilityEnabled = isAccessibilityEnabled,
                isOverlayEnabled = isOverlayEnabled,
                onOpenAccessibility = onOpenAccessibility,
                onOpenOverlay = onOpenOverlay
            )

            // Hero Live Stats Card
            HeroCounterCard(
                stats = stats,
                isOverlayShowing = isOverlayPreviewShowing,
                onResetClicked = { showResetConfirmDialog = true },
                onSetLimitClicked = { showSetLimitDialog = true },
                onToggleOverlayPreview = onToggleOverlayPreview
            )

            // Interactive Simulator
            ReelsSimulatorSection(
                onManualSwipe = onManualSwipe
            )

            // Target Platforms Grid & Toggles
            PlatformGridSection(
                stats = stats,
                settings = settings,
                onTogglePlatform = { platform, isEnabled ->
                    val updated = when (platform) {
                        VideoPlatform.INSTAGRAM -> settings.copy(trackInstagram = isEnabled)
                        VideoPlatform.YOUTUBE -> settings.copy(trackYouTube = isEnabled)
                        VideoPlatform.TIKTOK -> settings.copy(trackTikTok = isEnabled)
                        VideoPlatform.FACEBOOK -> settings.copy(trackFacebook = isEnabled)
                        VideoPlatform.DEMO -> settings.copy(trackDemo = isEnabled)
                    }
                    onUpdateSettings(updated)
                }
            )

            // General Preferences Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("preferences_card"),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2C2744))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Behavior & Alerts",
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )

                    // Vibration Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Vibration,
                                contentDescription = null,
                                tint = CoralPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Haptic Vibration on Swipe",
                                    color = TextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    text = "Vibrates gently when a short video is counted",
                                    color = TextMuted,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Switch(
                            checked = settings.vibrateOnScroll,
                            onCheckedChange = {
                                onUpdateSettings(settings.copy(vibrateOnScroll = it))
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = CoralPrimary,
                                uncheckedThumbColor = TextMuted,
                                uncheckedTrackColor = DarkElevatedSurface
                            )
                        )
                    }

                    // Auto-hide overlay when leaving video apps
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.VisibilityOff,
                                contentDescription = null,
                                tint = ElectricViolet,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Auto-Hide Outside Video Apps",
                                    color = TextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    text = "Only shows floating pill while inside Instagram/YouTube/TikTok",
                                    color = TextMuted,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Switch(
                            checked = settings.autoHideOverlay,
                            onCheckedChange = {
                                onUpdateSettings(settings.copy(autoHideOverlay = it))
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = ElectricViolet,
                                uncheckedThumbColor = TextMuted,
                                uncheckedTrackColor = DarkElevatedSurface
                            )
                        )
                    }
                }
            }

            // Past 7 Days History
            HistorySection(historyList = history)

            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Dialogs
    if (showSetLimitDialog) {
        SetLimitDialog(
            currentLimit = stats.dailyLimit,
            onDismiss = { showSetLimitDialog = false },
            onSaveLimit = { newLimit ->
                onSaveLimit(newLimit)
                showSetLimitDialog = false
            }
        )
    }

    if (showResetConfirmDialog) {
        ResetConfirmDialog(
            onDismiss = { showResetConfirmDialog = false },
            onConfirmReset = {
                onResetToday()
                showResetConfirmDialog = false
            }
        )
    }

    if (showGuideDialog) {
        SetupGuideDialog(
            onDismiss = { showGuideDialog = false },
            onOpenAccessibility = onOpenAccessibility,
            onOpenOverlay = onOpenOverlay
        )
    }
}
