package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SwipeVertical
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.VideoPlatform
import com.example.service.ReelCounterAccessibilityService
import com.example.ui.theme.CoralPrimary
import com.example.ui.theme.DarkCardSurface
import com.example.ui.theme.DarkElevatedSurface
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

data class MockReelItem(
    val title: String,
    val author: String,
    val tag: String,
    val likes: String,
    val gradientColors: List<Color>
)

val mockReels = listOf(
    MockReelItem(
        title = "Incredible Timelapse of Milky Way Over Dolomites 🌌",
        author = "@astro_wonders",
        tag = "#nature #astronomy #reels",
        likes = "142K",
        gradientColors = listOf(Color(0xFF1A102F), Color(0xFF321A5C), Color(0xFF6B117B))
    ),
    MockReelItem(
        title = "3 Android Jetpack Compose Tips in 30 Seconds ⚡",
        author = "@dev_byte",
        tag = "#android #kotlin #coding",
        likes = "38.5K",
        gradientColors = listOf(Color(0xFF0D1B2A), Color(0xFF1B4965), Color(0xFF0077B6))
    ),
    MockReelItem(
        title = "Crispy Garlic Butter Smashed Potatoes Recipe 🥔✨",
        author = "@foodie_craze",
        tag = "#recipes #cooking #shorts",
        likes = "519K",
        gradientColors = listOf(Color(0xFF2B1704), Color(0xFF632B08), Color(0xFFBD530D))
    ),
    MockReelItem(
        title = "Golden Retriever Reacts to Magic Trick Illusion 🐶",
        author = "@daily_pawz",
        tag = "#dogs #cute #tiktok",
        likes = "890K",
        gradientColors = listOf(Color(0xFF1D2A10), Color(0xFF385E1E), Color(0xFF588157))
    ),
    MockReelItem(
        title = "Cyberpunk Neo Tokyo Street Photography 📸",
        author = "@neon_visuals",
        tag = "#tokyo #cyberpunk #aesthetic",
        likes = "76.2K",
        gradientColors = listOf(Color(0xFF1F0D24), Color(0xFF5B116A), Color(0xFFE0218A))
    )
)

@Composable
fun ReelsSimulatorSection(
    onManualSwipe: (VideoPlatform) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("reels_simulator_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, ElectricViolet.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(ElectricViolet.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.SwipeVertical,
                            contentDescription = "Swipe Simulator",
                            tint = ElectricViolet,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Interactive Swipe Simulator",
                            color = TextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Swipe vertically below to test counter & pill live!",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Embedded Vertical Pager representing a Reel feed
            val pagerState = rememberPagerState(pageCount = { mockReels.size })
            var lastRecordedPage by remember { mutableIntStateOf(0) }

            LaunchedEffect(pagerState) {
                snapshotFlow { pagerState.currentPage }.collect { page ->
                    if (page != lastRecordedPage) {
                        lastRecordedPage = page
                        // Trigger count for Demo / Simulator
                        onManualSwipe(VideoPlatform.DEMO)
                    }
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(280.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, DarkElevatedSurface, RoundedCornerShape(16.dp))
            ) {
                VerticalPager(
                    state = pagerState,
                    modifier = Modifier.fillMaxSize()
                ) { page ->
                    val reel = mockReels[page]
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(reel.gradientColors)
                            )
                            .padding(16.dp)
                    ) {
                        // Play button indicator
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(Color.Black.copy(alpha = 0.4f))
                                .align(Alignment.Center),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Play",
                                tint = Color.White,
                                modifier = Modifier.size(28.dp)
                            )
                        }

                        // Right sidebar action icons
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(bottom = 12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Default.Favorite,
                                    contentDescription = "Likes",
                                    tint = CoralPrimary,
                                    modifier = Modifier.size(26.dp)
                                )
                                Text(
                                    text = reel.likes,
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Icon(
                                imageVector = Icons.Default.Bookmark,
                                contentDescription = "Bookmark",
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )

                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = "Share",
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        // Bottom Reel Info
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(end = 56.dp, bottom = 8.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(NeonCyan),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = reel.author.take(2).uppercase(),
                                        color = Color.Black,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = reel.author,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = reel.title,
                                color = Color.White,
                                fontSize = 12.sp,
                                maxLines = 2
                            )
                            Text(
                                text = reel.tag,
                                color = NeonCyan,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        // Top indicator banner
                        Row(
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.Black.copy(alpha = 0.5f))
                                .padding(horizontal = 10.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Reel #${page + 1} of ${mockReels.size}  •  Swipe up/down ↕",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Quick Manual +1 Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { onManualSwipe(VideoPlatform.INSTAGRAM) },
                    modifier = Modifier
                        .weight(1f)
                        .height(38.dp)
                        .testTag("btn_sim_ig"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE1306C))
                ) {
                    Text("+1 IG Reel", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = { onManualSwipe(VideoPlatform.YOUTUBE) },
                    modifier = Modifier
                        .weight(1f)
                        .height(38.dp)
                        .testTag("btn_sim_yt"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF0000))
                ) {
                    Text("+1 YT Short", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = { onManualSwipe(VideoPlatform.TIKTOK) },
                    modifier = Modifier
                        .weight(1f)
                        .height(38.dp)
                        .testTag("btn_sim_tt"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00ADB5))
                ) {
                    Text("+1 TikTok", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
