package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CoralPrimary = Color(0xFFFF4B4B)
val CoralPrimaryLight = Color(0xFFFF6E6E)
val ElectricViolet = Color(0xFF7C4DFF)
val NeonCyan = Color(0xFF00E5FF)
val WarningAmber = Color(0xFFFF9E00)
val DangerRed = Color(0xFFFF1744)

val DarkBackground = Color(0xFF0D0C15)
val DarkSurface = Color(0xFF161424)
val DarkCardSurface = Color(0xFF201D33)
val DarkElevatedSurface = Color(0xFF2B2745)

val TextPrimary = Color(0xFFF5F3FF)
val TextSecondary = Color(0xFFA6A0C0)
val TextMuted = Color(0xFF6B6588)

// Platform Specific Accents
val InstagramGradientStart = Color(0xFF833AB4)
val InstagramGradientEnd = Color(0xFFFD1D1D)
val YouTubeRed = Color(0xFFFF0000)
val TikTokCyan = Color(0xFF00F2FE)
val FacebookBlue = Color(0xFF1877F2)
